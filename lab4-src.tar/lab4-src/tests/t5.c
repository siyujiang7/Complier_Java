long main() {
  long g;
  g = 6 / 0;
}
