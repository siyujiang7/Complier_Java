long main() {
  return 0;
}

void P(double a, double b, char* c) {
  long m;
  m = "pizza" >= 2.3;
  return 1;
}

long F(char a) {
  a = g + 'b';
  return 2.3;
}

long G() {
  char* g;
  g = 2.3;
  return "dog";
}

long main() {
  long a;
  long g;
  long* m;
  char* lll;
  lll = -"dog";
  F();
  G('a');
  m["cat"] = 1 + a;
  a = 5;
  continue;
  break;
  long l;
  gg = 1;
  P("a", "b", 2.3);
  return 0;
}
