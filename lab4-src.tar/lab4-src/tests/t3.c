long main() {
  char* str;
  str = "not a long";
}
