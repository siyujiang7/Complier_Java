long a, b, c, d;

long main() {
  a = 1;
  b = 2;
  c = a + b;
  d = c - b;
  printf("%ld %ld\n", c, d);
}
