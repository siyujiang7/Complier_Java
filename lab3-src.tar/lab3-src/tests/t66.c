long main(){x = y * (z + a);}
