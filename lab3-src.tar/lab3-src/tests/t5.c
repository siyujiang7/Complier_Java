long main(){} double down(){}
