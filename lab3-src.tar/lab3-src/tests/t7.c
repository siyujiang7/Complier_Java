char* a; char** b; long c; long* d; void e; double f; double* g;
