void main()
{
  long x, z;
  char* y;
  x = 2 * (3 + 4);
  z = 10 / 3;
  y = "world";
  printf("x: %ld, y: %s, imm: %ld, z: %ld\n", x, y, 5, z);
}
