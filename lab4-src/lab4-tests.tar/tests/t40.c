void P(double a, double b, char* c, double d) {
  return;
}

long main() {
  P(1, 2.3, "dog", "cat");
  return 0;
}
