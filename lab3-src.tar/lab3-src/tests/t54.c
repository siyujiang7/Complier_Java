long main(){long h; h = a + b <= x - y;}
