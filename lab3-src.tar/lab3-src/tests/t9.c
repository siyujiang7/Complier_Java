long main(long a) {}
