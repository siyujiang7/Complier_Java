long main(long a) {
  long f;
  f = "asd";
}
