void main()
{
    printf("Hello world...\n");
}
