long main() {b=b+-a;}
