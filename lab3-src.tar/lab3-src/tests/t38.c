long main(){a = x != y;}
