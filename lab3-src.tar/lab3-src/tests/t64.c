long main(){b=a[r];}
