long G() {
  char* g;
  g = 2.3;
  return "dog";
}

