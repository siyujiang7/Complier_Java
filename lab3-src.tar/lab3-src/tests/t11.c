long main(){a = 1337;}
