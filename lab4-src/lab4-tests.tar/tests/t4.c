long main() {
  char* x;
  long g;
  x = "dog";
  g = x + 5;
}
