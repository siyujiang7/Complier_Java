long f() {
  printf("%s\n", x);
  long x;
}
