long main() {
  char* x;
  double g;
  x = "dog";
  g = x;
  return 1;
}
