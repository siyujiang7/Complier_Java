
void main()
{
	printf("9==8%d\n", 9==8);
	printf("9==9=%d\n", 9==9);

	printf("9!=8%d\n", 9!=8);
	printf("9!=9=%d\n", 9!=9);

}
