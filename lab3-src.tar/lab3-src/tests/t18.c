long main(){if(x) foo(); else bar();}
