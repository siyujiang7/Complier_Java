long main(){long l;}
