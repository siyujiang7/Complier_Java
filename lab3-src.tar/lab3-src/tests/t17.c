long main(){if(x) foo();}
