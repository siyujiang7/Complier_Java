long main() {
  long* x;
  x["dog"] = 5;
}
