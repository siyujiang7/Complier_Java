long main() {x=&a;}
