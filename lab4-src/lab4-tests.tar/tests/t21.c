long main() {
  long f;
  long f;
}
