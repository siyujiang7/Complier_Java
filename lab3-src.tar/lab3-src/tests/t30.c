long main(){do do foo(); while(j); while(i);}
