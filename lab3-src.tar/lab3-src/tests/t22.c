long main(){return 1337;}
