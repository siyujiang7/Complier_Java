
void compute(long a, long b)
{
	printf("a=%d b=%d\n", a, b);
}

void main()
{
	compute(6, 7);
}

