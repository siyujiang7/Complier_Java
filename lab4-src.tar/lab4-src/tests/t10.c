long main() {
  double dub;
  dub = 5;
  dub = -dub;
  dub = +dub;
}
