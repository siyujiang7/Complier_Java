long main() {
  long i;
  for (i = 1; i > 0; i = i + 1) {
    break;
  }
  printf("break works :)\n");
}
