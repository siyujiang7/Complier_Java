
void main()
{
	
	long* a;
	a = malloc(8*20);
	
	a[8]=9;
	printf("a[8]=%d\n", a[8]);
	
}
  
