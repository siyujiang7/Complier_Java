long main(){long x, y, z;}
