long main(){long d; d = a < b == x > y;}
