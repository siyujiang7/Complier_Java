long main() {d = 3.14;}
