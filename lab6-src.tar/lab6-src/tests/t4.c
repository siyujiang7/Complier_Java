long main() {
  printf("30: %ld\n", 10 + 20);
  printf("5: %ld\n", 1 + 2 + 2);
}
