long f() {
  return 'k';
}

long main() {
  long g;
  g = f();
}
