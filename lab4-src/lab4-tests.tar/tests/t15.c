long f(long g) {

}

long main() {
  f();
}
