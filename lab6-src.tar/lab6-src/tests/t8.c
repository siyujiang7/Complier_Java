long main() {
  long g, c, h;
  // Prints A-Z
  for (g = 65; g < 91; g = g + 1) {
    putchar(g);
  }
}
