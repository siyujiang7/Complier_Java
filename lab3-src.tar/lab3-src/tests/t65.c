long main(){x = foo();}
