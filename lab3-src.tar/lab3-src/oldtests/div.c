
void main()
{
	printf("88/11=%d\n", 88/11);
	printf("83%11=%d\n", 83%11);
}
