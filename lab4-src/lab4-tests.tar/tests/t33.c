long main(char f) {
  long f;
  char f;
  char* f;
  char** f;
  double f;
  double* f;
  return "dog";
}

long f(char g) {
  return f(g);
}

long main(char g) {
  f(g);
}
