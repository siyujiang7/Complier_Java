long main() {

}
