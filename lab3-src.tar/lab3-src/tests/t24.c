long main() {while(x) {continue;}}
