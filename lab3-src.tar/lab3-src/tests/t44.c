long main(){a = x < y <= z > f >= g;} 
