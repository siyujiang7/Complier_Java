long main(){foo(bar, baz);}
