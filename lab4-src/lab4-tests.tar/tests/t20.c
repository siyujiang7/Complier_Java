long f(char a) {
  a = 'b';
  return a;
}

long main() {
  long g;
  g = f(5);
}
