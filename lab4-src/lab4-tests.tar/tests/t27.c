void f() {
  return 2;
}

long main() {
  f();
}
