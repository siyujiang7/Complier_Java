long main(){a = x || y || z;}
