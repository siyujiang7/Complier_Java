long main(){ if(root) if (left) if (leftleft) f(); else f(); else if (rightleft) f(); else f(); else f();}
