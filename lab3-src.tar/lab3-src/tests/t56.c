long main() {x=-a;}
