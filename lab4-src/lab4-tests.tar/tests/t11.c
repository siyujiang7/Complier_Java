long main() {
  long c;
  c = 'a';
  c = 5.3;
}
