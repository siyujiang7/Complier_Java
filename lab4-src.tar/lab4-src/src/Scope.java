package simplec;

import java.util.*;
import simplec.parse.*;

public class Scope {
  public static Scope rootScope = null;
  public static Scope topScope = null;
  public Scope(Scope par) {
    // TODO: Implement scope/symbol tables
    // Feel free to implement this in any way you want
    // Just make sure that while parsing, topScope refers
    // to the current scope. Whenever we make a new variable
    // or statement, we just set that objects scope to be
    // Scope.topScope, which makes some other things easier.
  }
}
