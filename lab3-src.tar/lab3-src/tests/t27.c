long main(){while(i) foo();}
