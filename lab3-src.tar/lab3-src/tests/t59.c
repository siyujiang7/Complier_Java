long main() {x=*a;}
