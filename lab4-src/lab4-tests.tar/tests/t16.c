long f(double x) {
}

long main() {
  char* g;
  long h;
  g = "dog";
  h = f(g);
}
