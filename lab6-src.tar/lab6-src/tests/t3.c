long main() {
  long x;
  x = 2 * 7 + 3;
  printf("%ld\n", x);
}
