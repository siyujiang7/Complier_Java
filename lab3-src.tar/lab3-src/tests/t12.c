long main(){a[42]=24;}
