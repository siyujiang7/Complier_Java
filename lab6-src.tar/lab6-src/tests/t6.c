long main() {
  long i;
  for (i = 0; i < 5; i = i + 1) {
    printf("%d\n", i);
  }
  printf("done!\n");
}
