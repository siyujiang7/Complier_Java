long main() {x=+a;}
