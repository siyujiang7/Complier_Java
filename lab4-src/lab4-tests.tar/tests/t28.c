char* x() {
  return 2.3;
}

long main() {
  char* g;
  g = x();
}
