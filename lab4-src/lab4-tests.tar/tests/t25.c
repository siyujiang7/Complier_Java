long main() {
  long x;
  x = y / (y / g * f / 0);
}
