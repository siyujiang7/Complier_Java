long main() {
  double x;
  double g;
  char* str;
  str = "long string";
  g = 5.3213;

  x = str[0];
  x = str[g];

  return -1;
}
