struct a {
  long b;
  long c;
};
