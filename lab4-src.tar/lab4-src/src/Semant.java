package simplec;

import java.math.BigInteger;
import java.util.*;

import simplec.parse.*;
import static simplec.AST.*;

public class Semant {

  private static void usage() {
    throw new java.lang.Error("Usage: java simplec.Semant <source>.c");
  }

  private Semant() { }

  public static void main(String... args) {
    try {
      Value.Unit goal = new SimpleC(System.in).goal();
      //Uncomment this if you want the AST to print
      //new Print(goal);
      Semant semant = new Semant();
      semant.typeCheck(goal);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  void typeCheck(Value v) {
    if (v == null) return;
    v.accept(new Value.Visitor<Void>() {
      public Void visit(Value.Unit v) {
        for (Value fov : v.fovList) {
          typeCheck(fov);
        }
        return null;
      }

      public Void visit(Value.Variable v) {
        typeCheck(v.type);
        return null;
      }

      public Void visit(Value.Argument v) {
        typeCheck(v.type);
        return null;
      }

      public Void visit(Value.Type v) {
        return null;
      }

      public Void visit(Value.ScalarAccess v) {
        return null;
      }

      public Void visit(Value.Function v) {
        typeCheck(v.varType);
        for (Value arg : v.argList) {
          typeCheck(arg);
        }
        typeCheck(v.cStmt);
        return null;
      }

      public Void visit(Value.VariableList v) {
        for (Value value : v.vars) {
          typeCheck(value);
        }
        return null;
      }
    });
  }

  void typeCheck(Statement stmt) {
    if (stmt == null) return;
    stmt.accept(new Statement.Visitor<Void>() {
      public Void visit(Statement.CompoundStatement stmt) {
        // SimpleC forbids mixed declarations and code (just like C90)
        // So we need to set a flag once we've seen code, and make sure
        // no variable declarations follow
        boolean seenNonDecl = false;
        for (Statement s : stmt.stmtList) {
          if (s instanceof Statement.VariableDecls) {
            if (seenNonDecl) {
              Error.MixedDeclarations(stmt.id);
            }
          } else {
            seenNonDecl = true;
          }
          typeCheck(s);
        }
        return null;
      }

      public Void visit(Statement.VariableDecls decls) {
        for (Value.Variable var : decls.vars) {
          typeCheck(var);
        }
        return null;
      }

      public Void visit(Statement.AssignStatement stmt) {
        CType lhs = getType(stmt.var);
        CType rhs = getType(stmt.expression);
        if (lhs == null) {
          // Note that until you add scope, this might
          // say every variable is undeclared
          Error.UndeclaredVariable(stmt.id, stmt.var);
          return null;
        }
        
        return null;
      }

      public Void visit(Statement.ForStatement stmt) {
        typeCheck(stmt.init);
        CType condType = getType(stmt.cond);
        typeCheck(stmt.update);
        typeCheck(stmt.body);
        return null;
      }

      public Void visit(Statement.WhileStatement stmt) {
        CType condType = getType(stmt.cond);
        typeCheck(stmt.body);
        return null;
      }

      public Void visit(Statement.DoWhileStatement stmt) {
        CType condType = getType(stmt.cond);
        typeCheck(stmt.body);
        return null;
      }

      public Void visit(Statement.IfStatement stmt) {
        CType condType = getType(stmt.cond);
        typeCheck(stmt.body);
        if (stmt.elseStmt != null)
          typeCheck(stmt.body);
        return null;
      }

      public Void visit(Statement.ElseStatement stmt) {
        typeCheck(stmt.body);
        return null;
      }

      public Void visit(Statement.CallStatement stmt) {
        CType exprType = getType(stmt.callExpr);
        return null;
      }

      public Void visit(Statement.ContinueStatement stmt) {
        return null;
      }

      public Void visit(Statement.BreakStatement stmt) {
        return null;
      }

      public Void visit(Statement.ReturnStatement stmt) {
        CType type = getType(stmt.retVal);
        return null;
      }
    });

  }

  public CType getType(Value var) {
    if (var == null) return null;
    return var.accept(new Value.Visitor<CType>() {
      public CType visit(Value.Unit v) {
        return null;
      }

      public CType visit(Value.Variable v) {
        return getType(v.type);
      }

      public CType visit(Value.Argument v) {
        return null;
      }

      public CType visit(Value.Type v) {
        return v.type;
      }

      public CType visit(Value.ScalarAccess v) { 
        return null;
      }

      public CType visit(Value.Function v) {
        return getType(v.varType);
      }

      public CType visit(Value.VariableList v) {
        if (v.vars.size() > 0)
          return getType(v.vars.get(0));
        return null;
      }
    });
     
  }

  public CType getType(Expression expr) {
    return expr.accept(new Expression.Visitor<CType>() {
      public CType visit(Expression.Or expr) {
        CType lhs = getType(expr.left);
        CType rhs = getType(expr.right);

        if (lhs == rhs)
          return lhs;
        return null;
      }

      public CType visit(Expression.And expr) {
        CType lhs = getType(expr.left);
        CType rhs = getType(expr.right);

        if (lhs == rhs)
          return lhs;
        return null;
      }

      public CType visit(Expression.Eq expr) {
        CType lhs = getType(expr.left);
        CType rhs = getType(expr.right);

        if (lhs == rhs)
          return lhs;
        return null;
      }

      public CType visit(Expression.Rel expr) {
        CType lhs = getType(expr.left);
        CType rhs = getType(expr.right);

        if (lhs == rhs)
          return lhs;
        return null;
      }

      public CType visit(Expression.Add expr) {
        CType lhs = getType(expr.left);
        CType rhs = getType(expr.right);

        if (lhs == rhs)
          return lhs;
        return null;
      }

      public CType visit(Expression.Mul expr) {
        CType lhs = getType(expr.left);
        CType rhs = getType(expr.right);

        if (lhs == rhs)
          return lhs;
        return null;
      }

      public CType visit(Expression.Ref expr) {
        CType inside = getType(expr.expr);
        return null;
      }

      public CType visit(Expression.Deref expr) {
        CType inside = getType(expr.expr);
        return null;
      }

      public CType visit(Expression.Negative expr) {
        CType inside = getType(expr.expr);
        return null;
      }

      public CType visit(Expression.Positive expr) {
        CType inside = getType(expr.expr);
        return null;
      }

      public CType visit(Expression.Char expr) { return CType.CHAR; }
      public CType visit(Expression.Text expr) { return CType.CHARSTAR; }
      public CType visit(Expression.Int expr)  { return CType.LONG; }
      public CType visit(Expression.Double expr) { return CType.DOUBLE; }

      public CType visit(Expression.ID id) {
        return null;
      }

      public CType visit(Expression.Call expr) {
        return null;
      }

      public CType visit(Expression.Array expr) {
        return null;
      }
    });
  }
}
