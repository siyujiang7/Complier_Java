long main(){long k; k = a * b + x * y;}
