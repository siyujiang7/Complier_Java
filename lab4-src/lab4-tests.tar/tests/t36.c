long main()
{
  long res;
  char* str;
  char** strstar;
  double dub;
  double* dubstar;
  long num;
  long* numstar;

  res = 1.5 > 2.0;
  res = 1.5 <= 'a';

  if (num == 1) return 0;
  return -1;
}
