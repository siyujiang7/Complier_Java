long main() {
  char* x;
  x = -"dog";
}
