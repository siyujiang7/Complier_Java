long f() {
  long g;
  g = 5 * (2 - 3 / 1 * (2.3 - y));
}
