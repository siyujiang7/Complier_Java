
long i;

void main()
{
	i = 0;
	
	while (i<9) {
		printf("i=%d\n", i);
		i=i+1;
	}

	printf("OK\n");
}

