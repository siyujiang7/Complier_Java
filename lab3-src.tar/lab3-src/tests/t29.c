long main(){do foo(); while(i);}
