long main() {s = "A string called s";}
