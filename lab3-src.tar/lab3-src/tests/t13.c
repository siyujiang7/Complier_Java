long main(){foo();}
