long main() {
  printf("%d\n", 5);
}
