long main(){long x; x = a && b || x && y;}
