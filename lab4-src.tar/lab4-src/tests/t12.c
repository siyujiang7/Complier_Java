long main() {
  char a;
  char* f;
  long m;
  a = 'k';
  f = &a;
  m = f;
}
