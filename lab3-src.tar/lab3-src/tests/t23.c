long main() {while(x) {break;}}
