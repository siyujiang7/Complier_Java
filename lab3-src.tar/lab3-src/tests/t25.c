long main(){for(i=0; i<l;i=0) foo();}
