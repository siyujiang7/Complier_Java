
long i;

void main()
{
	i = 0;
	
	do {
		printf("i=%d\n", i);
		i=i+1;
	}
	while (i<11);
		
	printf("OK\n");
}

