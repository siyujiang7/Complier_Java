void f() {

}

long main() {
  f(1);
}
