long main(){while(i) while(j) foo();}
