void main() {
  do {
    if (1) {
      printf("this should print once\n");
    }
  } while (1 < 0);
}

