long main() {
  long g;
}

long main() {
  long f;
}
