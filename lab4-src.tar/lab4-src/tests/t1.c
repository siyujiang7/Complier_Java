long main() 
{
  x = 3;
}
