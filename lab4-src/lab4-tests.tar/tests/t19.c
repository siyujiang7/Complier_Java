long main() {
  long x;
  x = 5 * "dog";
}
