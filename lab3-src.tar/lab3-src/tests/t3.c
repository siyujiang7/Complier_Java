long a, b, c;
