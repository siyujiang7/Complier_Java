long g;
char h;
long f() {
  long m;
  char* l;
  h = 'a';
  g = 3;
  m = *g;
  l = &h;
}
