char*x,y;long main(){}long d,y,eee;double notmain(){}
