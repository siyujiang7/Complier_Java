long main(long x, long y, long z){}
