long main(){x = y;}
