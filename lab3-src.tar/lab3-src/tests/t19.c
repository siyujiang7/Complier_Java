long main(){if(x) if(y) bar(); else baz(); foo();}
