long main() {
  long x;
  x = "dog" > 5.3;
}
